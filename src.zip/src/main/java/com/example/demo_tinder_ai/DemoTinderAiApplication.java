package com.example.demo_tinder_ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoTinderAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoTinderAiApplication.class, args);
	}

}
